/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v2;

public class StudentInformation {
    
    //variables
    int id;
    
    String name;
    
    int age;
    
    String email;
    
    String course;

    //constructor
    public StudentInformation(int id, String name, int age, String email, String course) {
        
        this.id = id;
        
        this.name = name;
        
        this.age = age;
        
        this.email = email;
        
        this.course = course;
    }
    
    
    //constructor 
    public void displayStudInfo() {
            
        System.out.println("STUDENT ID: " + id);
        
        System.out.println("STUDENT NAME: " + name);
        
        System.out.println("STUDENT AGE: " + age); 
        
        System.out.println("STUDENT EMAIL: " + email);
        
        System.out.println("STUDENT COURSE: " + course);
    }
}
