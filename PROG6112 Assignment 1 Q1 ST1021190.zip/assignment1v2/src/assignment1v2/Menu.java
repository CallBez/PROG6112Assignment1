/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v2;


public class Menu {
    
    //method to display the menu
    public void display(){
        
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("*******************************************");
        System.out.println("Please select one of the following menu items:");
        
        System.out.println("(1) Capture a new student.");
        
        System.out.println("(2) Search for a student.");
        
        System.out.println("(3) Delete a student.");
        
        System.out.println("(4) Print student report.");
        
        System.out.println("(5) Exit application.");
    }
    
}
