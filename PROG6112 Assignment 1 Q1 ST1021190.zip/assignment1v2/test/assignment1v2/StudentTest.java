/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package assignment1v2;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author caleb
 */
public class StudentTest {
    
    @Test
    public void TestSaveStudent() {
        
        //test instance of Student
        Student student = new Student();

        // test instance of Scanner
        Scanner mockScanner = new Scanner("10111\nJackie Sharp\n60\njsharp69@example.com\nBiology");

        // Capture a new student using the test input
        student.captureNewStudent(mockScanner);

        // Get the list of students from Student
        List<StudentInformation> students = Student.students;

        // Verify that the student has been saved correctly
        assertEquals(1, students.size()); // There should be one student in the list

        // Get the saved student
        StudentInformation savedStudent = students.get(0);

        // Verify the attributes of the saved student
        assertEquals(10111, savedStudent.id);
        assertEquals("Jackie Sharp", savedStudent.name);
        assertEquals(60, savedStudent.age);
        assertEquals("jsharp69@example.com", savedStudent.email);
        assertEquals("Biology", savedStudent.course);
    }
    
    @Test
    public void TestSearchStudent() {
 

    }
    
    @Test
    public void TestSearchStudent_StudentNotFound(){
        
    }
    
    @Test
    public void TestDeleteStudent() {

    }
    
    @Test
    public void TestDeleteStudent_StudentNotFound() {
        
    }
    
    @Test
    public void TestStudentAge_StudentAgeValid() {
        
        //test instance of Student
        Student student = new Student();
        
        //i am simulating user input by using an input stream, as this is a unit test
        String input = "10111\nJackie Sharp\n60\njsharp60@example.com\nBiology\n"; 
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        // Calling the captureNewStudent method
        student.captureNewStudent(new Scanner(System.in));

        // verrifying that correct student details were saved
        List<StudentInformation> students = student.students;
        assertEquals(1, students.size()); // Ensure one student is added

        StudentInformation savedStudent = students.get(0);
        assertEquals(10111, savedStudent.id);
        assertEquals("Jackie Sharp", savedStudent.name);
        assertEquals(60, savedStudent.age);
        assertEquals("jsharp60@example.com", savedStudent.email);
        assertEquals("Biology", savedStudent.course);
        
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalid() {

    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        
    }
    
    
    
    
}
